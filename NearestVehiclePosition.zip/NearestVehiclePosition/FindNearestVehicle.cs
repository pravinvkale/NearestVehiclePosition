﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Device.Location;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NearestVehiclePosition
{
    class FindNearestVehicle : IDisposable
    {
        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    filePosition.Clear();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~FindNearestVehicle() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

        int dividedBlocks = 4;
        int positionId = 0;
        double latitude = 0;
        double longitude = 0;
        ulong recordedTimeUTC = 0;
        string vehicleRegistraton = string.Empty;

        private static ConcurrentBag<VehicleDetailsVO> vehicleDetails = new ConcurrentBag<VehicleDetailsVO>();

        string file = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Input\VehiclePositions.dat");

        public List<FilePosition> filePosition = new List<FilePosition>();

        #region Read data file using Blocks

        public void ReadFile()
        {
            long fileLength;
            long startposition = 0;
            long endposition = 0;
            List<Task> tasksRead = new List<Task>();
            FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read);
            fileLength = fileStream.Length;
            for (int i = 1; i <= dividedBlocks; i++)
            {
                if (i == 1)
                {
                    startposition = 0;
                    endposition = (fileLength / dividedBlocks); //100/4 =25
                }
                else
                {
                    startposition = (fileLength / dividedBlocks) * (i - 1); //(100/4) * (2-1) = 25, (100/4) * (3-1) = 50 , , (100/4) * (4-1) = 75
                    endposition = ((fileLength / dividedBlocks) * i);
                }

                filePosition.Add(new FilePosition
                {
                    startPosition = startposition,
                    endPosition = endposition
                });
            }

            foreach (FilePosition item in filePosition)
            {
                ReadBlocks(item.startPosition, item.endPosition);                
            }

            //await Task.Run(() =>
            //{
            //    Parallel.ForEach(filePosition, item =>
            //    {
            //        Task.Factory.StartNew(() => ReadBlocks(item.startPosition, item.endPosition));
            //    });
            //});

            fileStream.Dispose();
        }

        public void ReadBlocks(long fileStartPosition, long fileEndPosition)
        {
            using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
            {
                fileStream.Seek(fileStartPosition, SeekOrigin.Begin);
                using (var binaryReader = new BinaryReader(fileStream))
                {
                    while (binaryReader.BaseStream.Position != fileEndPosition)
                    {
                        positionId = binaryReader.ReadInt32();
                        vehicleRegistraton = Encoding.ASCII.GetString(binaryReader.ReadBytes(10).ToArray());
                        latitude = binaryReader.ReadSingle();
                        longitude = binaryReader.ReadSingle();
                        recordedTimeUTC = binaryReader.ReadUInt64();
                        vehicleDetails.Add(new VehicleDetailsVO
                        {
                            PositionId = positionId,
                            VehicleRegistraton = vehicleRegistraton,
                            Latitude = latitude,
                            Longitude = longitude,
                            RecordedTimeUTC = recordedTimeUTC
                        });
                    }

                    binaryReader.Dispose();
                }

                fileStream.Dispose();
            }
        }

        #endregion
        public void CalculateDistance()
        {
            try
            {
                ConcurrentBag<Task<VehicleDetailsVO>> tasks = new ConcurrentBag<Task<VehicleDetailsVO>>();
                foreach (Coordinates item in Coordinates.inputCoordinates)
                {
                    Task<VehicleDetailsVO> taskToFindVehicle = Task.Run(() => getCoordinates(item.inputLatitude, item.inputLongitude, vehicleDetails));
                    tasks.Add(taskToFindVehicle);
                }

                Task.WaitAll(tasks.ToArray());
                foreach (Task<VehicleDetailsVO> task in tasks)
                {
                    Console.WriteLine("For Input Latitude: {0} \nFor Input Longitude: {1} ",
                        task.Result.inputLatitude, task.Result.inputLongitude);
                    Console.WriteLine("\t Position ID: {0} \n\t Registration Number: {1} \n\t Distance of Vehicle: {2} \n\t Recorder Time UTC: {3} \n",
                        task.Result.PositionId, task.Result.VehicleRegistraton, task.Result.Distance, task.Result.RecordedTimeUTC);
                }

                tasks = null;
            }
            finally
            {
                vehicleDetails = null;
            }
        }

        public async Task<VehicleDetailsVO> getCoordinates(double latitude, double longitude, ConcurrentBag<VehicleDetailsVO> vehicledetail)
        {
            VehicleDetailsVO nearVehicle = new VehicleDetailsVO();
            GeoCoordinate coord = new GeoCoordinate(latitude, longitude);
            double minDistance = double.MaxValue;
            await Task.Run(() =>
            {
                Parallel.ForEach(vehicledetail, item =>
                {
                    GeoCoordinate compareToCoordinate = new GeoCoordinate(item.Latitude, item.Longitude);
                    var distance = coord.GetDistanceTo(compareToCoordinate);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        nearVehicle.PositionId = item.PositionId;
                        nearVehicle.VehicleRegistraton = item.VehicleRegistraton;
                        nearVehicle.RecordedTimeUTC = item.RecordedTimeUTC;
                        nearVehicle.inputLatitude = latitude;
                        nearVehicle.inputLongitude = longitude;
                        nearVehicle.Distance = distance;
                    }
                });
            });

            return nearVehicle;
        }
      
        ~FindNearestVehicle()
        {
            Dispose();
        }
    }
}
