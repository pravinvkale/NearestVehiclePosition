﻿using System.Collections.Generic;

namespace NearestVehiclePosition
{
    class Coordinates
    {
        public double inputLatitude { get; set; }
        public double inputLongitude { get; set; }

        public static List<Coordinates> inputCoordinates = new List<Coordinates>
        {
            new Coordinates {inputLatitude=34.544909,inputLongitude=-102.100843},
            new Coordinates {inputLatitude=32.345544,inputLongitude=-99.123124},
            new Coordinates {inputLatitude=33.234235,inputLongitude=-100.214124},
            new Coordinates {inputLatitude=35.195739,inputLongitude=-95.348899},
            new Coordinates {inputLatitude=31.895839,inputLongitude=-97.789573},
            new Coordinates {inputLatitude=32.895839,inputLongitude=-101.789573},
            new Coordinates {inputLatitude=34.115839,inputLongitude=-100.225732},
            new Coordinates {inputLatitude=32.335839,inputLongitude=-99.992232},
            new Coordinates {inputLatitude=33.535339,inputLongitude=-94.792232},
            new Coordinates {inputLatitude=32.234235,inputLongitude=-100.222222}
       };
    }

    public class FilePosition
    {
        public long startPosition { get; set; }

        public long endPosition { get; set; }
    }
}
