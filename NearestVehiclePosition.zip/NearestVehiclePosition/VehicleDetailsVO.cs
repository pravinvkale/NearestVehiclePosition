﻿namespace NearestVehiclePosition
{
    class VehicleDetailsVO
    {
        public int PositionId { get; set; }

        public string VehicleRegistraton { get; set; }

        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public double Distance { get; set; }

        public ulong RecordedTimeUTC { get; set; }

        public double inputLatitude { get; set; }

        public double inputLongitude { get; set; }
    }
}
