﻿using System;

namespace NearestVehiclePosition
{
    class Program
    {
        private static DateTime startTime = DateTime.Now;

        public static DateTime StartTime
        {
            get
            {
                return startTime;
            }

            set
            {
                startTime = value;
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Start time:{0}", StartTime);
            FindNearestVehicle nearestVehicle = new FindNearestVehicle();
            nearestVehicle.ReadFile();
            //nearestVehicle.ReadFile().Wait();
            nearestVehicle.CalculateDistance();
            DateTime endTime = DateTime.Now;
            Console.WriteLine("End time:{0}", endTime);
            TimeSpan tSpan = endTime - StartTime;
            Console.WriteLine("Time for calculating Nearest Vehicle: {0} Seconds", tSpan.TotalMilliseconds);
            Console.Read();
            nearestVehicle.Dispose();
        }
    }
}
